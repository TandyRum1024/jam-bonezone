BONEZONE CLEANUP
Afterlife park-wandering cleaner simulator
=============================
Story :
While you're strolling around the Hell with a free 15 days trial of Hell after you've perished,
You ended up on very strange & unknown park, BONE ZONE.
To make things worse, A security officer of the park caught you, And he wants to punish you for (unwillingly) trespassing the park... By making you stay forever in the park.
But fortunately, The officer saw your "Hell tourist" coupon and decided to reduce the punishment into park-cleaning chore.
Now, You have to pick up every junks in the park!

----------------------------------------------

Your mission :
Pick up every junks in the park...
Friendly people trapped in the park can help you locating the junks.

How to play :
<LEFT / RIGHT> : Turn around
<UP / DOWN> : Forward / backward
<SHIFT> : Hold to sprint
<Z> : Interact with NPCs

Junks are highlighted by flashing effect around them.
To pick them up, Just get close to it then you'll automatically pick it up.

===============================
Happy cleaning, Mortals.
MMXIX ZIK